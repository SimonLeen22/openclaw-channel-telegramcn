/**
 * SNI Transparent Proxy
 *
 * 运行在首尔服务器上，监听 443 端口。
 * 读取 TLS ClientHello 中的 SNI 字段，
 * 将 api.telegram.org 的 TCP 流量原样透传到 Telegram 真实服务器。
 * 不终结 TLS，证书由 Telegram 服务器直接返回给客户端。
 *
 * 用法：sudo node sni-proxy.js
 * 或通过 systemd 管理（见 README）
 */

const net = require("net");

const LISTEN_PORT = 443;
const ALLOWED_HOSTS = ["api.telegram.org"];

const server = net.createServer((clientSocket) => {
  clientSocket.once("data", (data) => {
    const sni = extractSNI(data);

    if (!sni || !ALLOWED_HOSTS.includes(sni)) {
      console.log(`[${ts()}] REJECT sni=${sni || "null"} from=${clientSocket.remoteAddress}`);
      clientSocket.destroy();
      return;
    }

    console.log(`[${ts()}] PROXY ${clientSocket.remoteAddress} -> ${sni}:443`);

    const remote = net.createConnection(443, sni, () => {
      remote.write(data);
      clientSocket.pipe(remote);
      remote.pipe(clientSocket);
    });

    remote.on("error", (err) => {
      console.error(`[${ts()}] REMOTE_ERR ${sni} ${err.message}`);
      clientSocket.destroy();
    });
  });

  clientSocket.on("error", (err) => {
    console.error(`[${ts()}] CLIENT_ERR ${err.message}`);
  });

  clientSocket.setTimeout(10000, () => {
    console.log(`[${ts()}] TIMEOUT from=${clientSocket.remoteAddress}`);
    clientSocket.destroy();
  });
});

function ts() {
  return new Date().toISOString();
}

function extractSNI(buf) {
  try {
    if (buf.length < 5 || buf[0] !== 0x16) return null;
    let offset = 5;
    if (buf[offset] !== 0x01) return null;
    offset += 4;
    offset += 2 + 32;
    const sessionLen = buf[offset];
    offset += 1 + sessionLen;
    const cipherLen = buf.readUInt16BE(offset);
    offset += 2 + cipherLen;
    const compLen = buf[offset];
    offset += 1 + compLen;
    if (offset + 2 > buf.length) return null;
    const extTotal = buf.readUInt16BE(offset);
    offset += 2;
    const extEnd = offset + extTotal;
    while (offset + 4 <= extEnd && offset + 4 <= buf.length) {
      const extType = buf.readUInt16BE(offset);
      const extLen = buf.readUInt16BE(offset + 2);
      offset += 4;
      if (extType === 0x0000) {
        if (offset + 5 > buf.length) return null;
        const nameLen = buf.readUInt16BE(offset + 3);
        if (offset + 5 + nameLen > buf.length) return null;
        return buf.toString("utf8", offset + 5, offset + 5 + nameLen);
      }
      offset += extLen;
    }
  } catch (e) {}
  return null;
}

server.on("error", (err) => {
  if (err.code === "EADDRINUSE") {
    console.error(`Port ${LISTEN_PORT} in use`);
    process.exit(1);
  }
  console.error(`Server error: ${err.message}`);
});

server.listen(LISTEN_PORT, "0.0.0.0", () => {
  console.log(`[${ts()}] SNI Proxy listening on :${LISTEN_PORT}`);
  console.log(`[${ts()}] Allowed: ${ALLOWED_HOSTS.join(", ")}`);
});

process.on("uncaughtException", (err) => {
  console.error(`[${ts()}] UNCAUGHT ${err.message}`);
});
